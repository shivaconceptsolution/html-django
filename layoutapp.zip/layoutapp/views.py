from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    return render(request,"layoutapp/index.html")
def aboutus(request):
    return render(request,"layoutapp/aboutus.html")
def services(request):
    return render(request,"layoutapp/services.html")
def gallery(request):
    return render(request,"layoutapp/gallery.html")
def contactus(request):
    return render(request,"layoutapp/contactus.html")