from django.contrib import admin
from .models import Registration,Student,Feedback
admin.site.register(Registration)
admin.site.register(Student)
admin.site.register(Feedback)