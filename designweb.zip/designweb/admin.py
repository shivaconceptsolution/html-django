from django.contrib import admin
from .models import Registration,Student,Feedback,Reply
admin.site.register(Registration)
admin.site.register(Student)
admin.site.register(Feedback)
admin.site.register(Reply)