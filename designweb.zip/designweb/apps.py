from django.apps import AppConfig


class DesignwebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'designweb'
