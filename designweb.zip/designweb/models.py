from django.db import models
from datetime import datetime
class Registration(models.Model):
    username=models.CharField(max_length=50)
    password=models.CharField(max_length=10)
    email=models.CharField(max_length=50)
    mobile=models.CharField(max_length=10)
    def __str__(self):
        return "username is "+str(self.username) + " password is "+str(self.password)
class Feedback(models.Model):
    username=models.CharField(max_length=50)
    feedbackdesc=models.CharField(max_length=50)
    feedrate=models.CharField(max_length=5)
    feedbackto=models.CharField(max_length=5)
    feedbackdate=models.DateTimeField(default=datetime.now, blank=True)
    def __str__(self):
        return "username is "+str(self.username) + " Feedback Desc " + self.feedbackdesc + "Feedback Rate " + self.feedrate + " Feedback to " + self.feedbackto
class Student(models.Model):
    rno=models.CharField(max_length=50)
    sname=models.CharField(max_length=50)
    def __str__(self):
        return "rno is "+ self.rno + " sname is "+self.sname
