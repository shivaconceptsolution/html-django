from django.shortcuts import render,redirect
from .models import Registration,Feedback
from django.http import HttpResponse
def index(request):
    if request.method=="POST":
        data=Registration.objects.filter(username=request.POST["txtuser"])
        if data.count()==0:
          obj = Registration(username=request.POST["txtuser"],password=request.POST["txtpass"],email=request.POST["txtemail"],mobile=request.POST["txtmobile"])
          obj.save()
          return render(request,"designweb/index.html",{"key":"Inserted Successfully"})
        else:
           return render(request,"designweb/index.html",{"key":"Registration Fail,Username already exist"})
    return render(request,"designweb/index.html")
def about(request):
    return render(request,"designweb/about.html")
def services(request):
    return render(request,"designweb/services.html")
def gallery(request):
    return render(request,"designweb/gallery.html")
def contacts(request):
    return render(request,"designweb/contact.html")
def login(request):
    if request.method=="POST":
        res= Registration.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"]);
        if(res.count()>0):
            request.session['uname']=request.POST["txtuser"]
            return redirect('profile')
        else:
            return render(request,"designweb/login.html",{"res":'invalid userid and password'})    
    return render(request,"designweb/login.html")    
def profile(request):
    ack=''
    if(request.session.has_key('uname')):
        if request.method=="POST":
            res = Feedback.objects.filter(username=request.session["uname"],feedbackto=request.POST['feedto'])
            if(res.count()==0):
              f = Feedback(username=request.session["uname"],feedbackdesc=request.POST["txtfeed"],feedrate=request.POST["txtfeedrate"],feedbackto=request.POST['feedto'])
              f.save()
              ack='Feedback submitted successfully'
            else:
              ack='Feedback Already Submitted'   
        obj = Registration.objects.filter(username=request.session['uname'])
        obj1 = Feedback.objects.filter(username=request.session['uname'])
        return render(request,"designweb/dashboard/profile.html",{'res':obj,'res1':obj1,'sessionkey':request.session['uname'],'ack':ack})
    else:
        return redirect('/designweb/login')   
def editprofile(request):
    id = request.GET["q"]
    obj = Registration.objects.get(pk=id)
    if request.method=="POST":
        obj.username=request.POST["txtuname"]
        obj.password=request.POST["txtpass"]
        obj.email=request.POST["txtemail"]
        obj.mobile=request.POST["txtmobile"]
        obj.save()
        return redirect('profile')

     #select * from Registration where id=id
    return render(request,"designweb/dashboard/editprofile.html",{'res':obj})

def deleteprofile(request):
    id = request.GET["q"]
    obj = Registration.objects.get(pk=id)
    if request.method=="POST":
        obj.delete()
        return redirect('profile')
    return render(request,"designweb/dashboard/deleteprofile.html",{'res':obj})
def logout(request):
    del request.session['uname']
    return redirect('/designweb/login')    