from django.shortcuts import render
def index(request):
    return render(request,"designweb/index.html")
def about(request):
    return render(request,"designweb/about.html")
def services(request):
    return render(request,"designweb/services.html")
def gallery(request):
    return render(request,"designweb/gallery.html")
def contacts(request):
    return render(request,"designweb/contact.html")