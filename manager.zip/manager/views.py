from django.shortcuts import render,redirect
from .models import MRegistration
from designweb.models import Feedback
def index(request):
    if request.method=="POST":
        res= MRegistration.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"]);
        if(res.count()>0):
            request.session['mname']=request.POST["txtuser"]
            request.session['desig'] = request.POST['feedto']
            return redirect('/manager/mprofile')
        else:
            return render(request,"manager/index.html",{"res":'invalid userid and password'})    
    return render(request,"manager/index.html")

def mprofile(request):
    if(request.session.has_key('mname')):
      sessfeedto=request.session['desig']
      sessuname=request.session['mname']
      res=Feedback.objects.filter(feedbackto=sessfeedto)
      return render(request,'manager/mprofile.html',{'key':res,'key1':sessuname})
    else:
        return redirect('/manager/')  
def logout(request):
    del request.session['mname']
    return redirect('/manager')  