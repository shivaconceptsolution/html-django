from django.contrib import admin
from .models import MRegistration
admin.site.register(MRegistration)
