from django.db import models
class MRegistration(models.Model):
    username=models.CharField(max_length=50)
    password=models.CharField(max_length=10)
    email=models.CharField(max_length=50)
    mobile=models.CharField(max_length=10)
    designation=models.CharField(max_length=10)
    def __str__(self):
        return "username is "+str(self.username) + " password is "+str(self.password)
