from django.contrib import admin
from .models import Registration,Student
admin.site.register(Registration)
admin.site.register(Student)
